﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using System.Threading.Tasks;
using ChoiceCustomerAPP.Web.Utilities;
using System.Text;
using System.Net;
using System.IO;
using System.Web.Script.Serialization;

namespace ChoiceCustomerAPP.Web.ChatHub
{
    public class ChatHub : Hub
    {
        private static readonly Dictionary<string, HashSet<string>> UserContextId = new Dictionary<string, HashSet<string>>();
        public void SendMessage(string name, string message, bool isAdmin, string toGroupID,string PushId)
        {



            if (UserContextId.Any() && !string.IsNullOrEmpty(message))
            {
                var cid = UserContextId.FirstOrDefault(i => i.Key == toGroupID);
                if (cid.Key != null)
                {
                    var fc = cid.Value.FirstOrDefault();
                    if (!string.IsNullOrEmpty(fc))
                    {
                        Clients.Client(fc).broadcastmessage(name, message, isAdmin);
                    }
                }
                var userId = Context.QueryString["userID"];
                var msg = new Message
                {
                    UserName = name,
                    FromGroupId = int.Parse(userId),
                    ToGroupId = int.Parse(toGroupID),
                    Text = message,
                    isAdmin=isAdmin
                };
                InsertChat(msg,PushId);
            }
        }
        public override Task OnConnected()
        {
            var userId = Context.QueryString["userID"];

            if (UserContextId.ContainsKey(userId))
            {
                var connections = new HashSet<string>();
                connections = UserContextId[userId];
                connections.Add(Context.ConnectionId);
                UserContextId[userId] = connections;
            }
            else
                UserContextId.Add(userId, new HashSet<string> { Context.ConnectionId });

            // Clients.All..Client(Context.ConnectionId);
            Groups.Add(Context.ConnectionId, userId);
            return base.OnConnected();

        }
        public override Task OnDisconnected(bool stopCalled)
        {
            var userId = Context.QueryString["userID"];
            if (UserContextId.ContainsKey(userId))
            {
                var connections = new HashSet<string>();
                connections = UserContextId[userId];
                connections.Remove(Context.ConnectionId);
                UserContextId[userId] = connections;
            }

            return base.OnDisconnected(stopCalled);
        }



        #region Groups
        public void AddToChatGroup(string newGroupId, string prevGroupId)
        {
            var userId = Context.QueryString["userID"];
            var connections = new HashSet<string>();

            //add user to the chat group
            if (UserContextId.ContainsKey(userId))
            {
                connections = UserContextId[userId];

                var enumarater = connections.GetEnumerator();
                if (prevGroupId != "")
                {
                    while (enumarater.MoveNext())
                    {
                        Groups.Remove(enumarater.Current, prevGroupId);
                        Groups.Add(enumarater.Current, newGroupId);
                    }
                }
                else
                    Groups.Add(Context.ConnectionId, newGroupId);
            }
        }

        #endregion


        #region Indiviual Chat

        //public void BroadcastIndividualMessage(string message, string fromId, string toId)
        //{
        //    var chat = new Chat.Message
        //    {
        //        Text = message,
        //        TimeStamp = DateTime.Now,
        //        UserName = Context.QueryString["userName"],
        //        UserId = int.Parse(fromId)

        //    };


        //    var groupsList = new List<string> { fromId, toId };
        //    Clients.Groups(groupsList).updateChat(chat, true, fromId);


        //}

        #endregion


        public void InsertChat(Message msg,string PushId)
        {
            var result = Api.Post("Admin/Insert", msg);
            if (msg.isAdmin)
            {
                
                var request = WebRequest.Create("https://onesignal.com/api/v1/notifications") as HttpWebRequest;

                request.KeepAlive = true;
                request.Method = "POST";
                request.ContentType = "application/json; charset=utf-8";

                request.Headers.Add("authorization", "Basic MTU5YTNiMzMtZDAyMC00ZjA1LWE0OTUtNGE0ZjZmYmMzNTk1");

                var serializer = new JavaScriptSerializer();
                var obj = new
                {
                    app_id = "2530a6a6-eeca-4fc5-9298-8228c9e99ff5",
                    contents = new { en = "You have a message." },
                    include_player_ids = new string[] {PushId}
                };



                var param = serializer.Serialize(obj);
                byte[] byteArray = Encoding.UTF8.GetBytes(param);

                string responseContent = null;

                try
                {
                    using (var writer = request.GetRequestStream())
                    {
                        writer.Write(byteArray, 0, byteArray.Length);
                    }

                    using (var response = request.GetResponse() as HttpWebResponse)
                    {
                        using (var reader = new StreamReader(response.GetResponseStream()))
                        {
                            responseContent = reader.ReadToEnd();
                        }
                    }
                }
                catch (WebException ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                    System.Diagnostics.Debug.WriteLine(new StreamReader(ex.Response.GetResponseStream()).ReadToEnd());
                }

                //   System.Diagnostics.Debug.WriteLine(responseContent);
            }
        }
        public class Chat
        {
            public class Group
            {
                public string Name { get; set; }
                public int GroupId { get; set; }
                public bool? IsDefault { get; set; }

                //extra-used only for sorting chat groups
                public int OrgCLassLevelId { get; set; }
                public int? OrgSectionLevelId { get; set; }
            }



            public class Contact
            {
                public int GroupId { get; set; }
                public string Name { get; set; }
                public long? UserId { get; set; }
                public bool IsOnline { get; set; }
            }
        }

        public class Message
        {
            public long MessageId { get; set; }

            public string UserName { get; set; }
            public int UserId { get; set; }

            public string Text { get; set; }
            public DateTime? TimeStamp { get; set; }
            public bool Isme { get; set; } //set when message belongs to current user

            public int FromGroupId { get; set; }
            public int ToGroupId { get; set; }
            public bool isAdmin { get; set; }
        }
    }
}