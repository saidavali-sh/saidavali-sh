﻿using ChoiceCustomerAPP.Web.Models;
using ChoiceCustomerAPP.Web.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ChoiceCustomerAPP.Web.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Login login )
        {
            
            var result = Api.Get("Admin/loginAdmin", login);
            if (!string.IsNullOrEmpty(result))
            {
                var response = JsonConvert.DeserializeObject<Login>(result);
                Session["UserDetails"] = response;
                return RedirectToAction("DashBoard", "Admin");
            }
            return View();
        }

       
    }
}