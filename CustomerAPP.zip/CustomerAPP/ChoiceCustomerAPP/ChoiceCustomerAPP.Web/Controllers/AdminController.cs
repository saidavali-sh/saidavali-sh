﻿using ChoiceCustomerAPP.Web.Models;
using ChoiceCustomerAPP.Web.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ChoiceCustomerAPP.Web.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult Index()
        {
            if (Session["UserDetails"] != null)
            {
                var login = Session["UserDetails"] as Login;
                ViewBag.UserName = login.UserName;
                ViewBag.UserId = login.UserId;
                ViewBag.isAdmin = login.isAdmin;
                return View();
            }
            return RedirectToAction("Login", "Login");
        }

        public ActionResult Ticket()
        {
            if (Session["UserDetails"] != null)
            {
                return View();
            }
            return RedirectToAction("Login", "Login");
        }
        public ActionResult TicketPage()
        {
            if (Session["UserDetails"] != null)
            {
                return View();
            }
            return RedirectToAction("Login", "Login");
        }
        public ActionResult DescriptionPage()
        {
            if (Session["UserDetails"] != null)
            {
                return View();
            }
            return RedirectToAction("Login", "Login");
        }
        public ActionResult DashBoard()
        {
            if (Session["UserDetails"] != null)
            {
                return View();
            }
            return RedirectToAction("Login", "Login");
        }
    }
}