﻿// App intialization for angular js
var app = angular.module('chat-app', ['luegg.directives']);
// route defining for app

//app.constant('serviceUrl', 'http://cslsupportapi.azurewebsites.net/');

app.constant('serviceUrl', 'http://localhost:55466/');

app.constant('serviceUrlLocal', 'http://localhost:50119/');




// chat controller 
app.controller('ChatController', function ($scope, $http, serviceUrl, $window, $filter) {
    // scope variables

    $scope.username = 'Admin'; // holds the user's name
    $scope.message = ''; // holds the new message
    $scope.isWindow = false;
    $scope.clientName = "";
    var data = null;
    var chatqs = {
        qs: {
            userID: $window.userId,
            toGroupID: "", //current active group/contact 
            defaultGroupID: "",  //logged in person default chat-groupId
            userName: $window.userName,
            PushId: ""
        }
    };
    var hubStarted = false;
    $scope.messages = []; // collection of messages coming from server
    $scope.clients = [];
    $scope.chatHub = null; // holds the reference to hub
    // $.connection.hub.url = 'http://10.10.3.85/signalr';
    $.connection.hub.qs = chatqs.qs;
    $scope.chatHub = $.connection.chatHub; // initializes hub

    $scope.chatHub.client.broadcastMessage = function (name, message, isAdmin) {

        if ($scope.clientName === name) {
            var newMessage = { msg: name + ':' + message, isAdmin: isAdmin };

            // push the newly coming message to the collection of messages
            $scope.messages.push(newMessage);
            $scope.$apply();
        }
    };

    $.connection.hub.start().done(function () {

        hubStarted = true;

    });

    // register a client method on hub to be invoked by the server

    $scope.newMessage = function () {

        if (hubStarted) {
            // Wire up Send button to call sendmessage on the server.
            $scope.chatHub.server.sendMessage($scope.username, $scope.message, true, chatqs.qs["toGroupID"], chatqs.qs["PushId"]);


            var newMessage = { msg: $scope.username + ':' + $scope.message, isAdmin: true };
            // push the newly coming message to the collection of messages
            $scope.messages.push(newMessage);
            if (!$scope.$$phase) {
                $scope.$apply();
            }

            $scope.message = '';
            // sends a new message to the server
        }


    };
    $scope.LoadClients = function () {
        $http.get(serviceUrl + "Admin/GetClients").then(function success(result) {

            $scope.clients = result.data;
            data = result.data;
            //angular.forEach(result.data, function (value, key) {

            //    $scope.clients = { username: value.UserName }
            //});
        },
            function error(result) {

            });
    };

    $scope.chatWindow = function ($event, c) {

        $scope.isWindow = true;
        $scope.messages = [];
        chatqs.qs["toGroupID"] = c.UserId;
        chatqs.qs["PushId"] = c.PushId;
        $scope.clientName = c.UserName;
        var config = {
            params: {
                UserId: chatqs.qs["userID"],
                ToUserId: c.UserId
            }
        }
        $http.get(serviceUrl + "Admin/GetChat", config).then(function success(result) {
            angular.forEach(result.data, function (value, key) {
                var newMessage = { msg: value.CreatedBy + ':' + value.Text, isAdmin: value.isAdmin };
                // push the newly coming message to the collection of messages
                $scope.messages.push(newMessage);

                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            });
        },
            function error(result) {

            }
        );



    };

    $scope.SearchClients = function () {

        var searchText = $scope.search

        $scope.clients = $filter('filter')(data, { UserName: searchText });
        if (!$scope.$$phase) {


            $scope.$apply();
        }
    };

});


// ticket controller
app.controller('ticketController', function ($scope, $http, serviceUrl, $window, $filter, $location) {
    $scope.tickets = [];
    $scope.isDesc = false;
    var datat = null;
    $scope.loadTickets = function () {
        $http.get(serviceUrl + "Admin/Tickets").then(function success(result) {
            $scope.tickets = result.data;
            datat = result.data;
        },
            function error() {

            });
    };
    $scope.title = "";
    $scope.subject = "";
    $scope.des = "";
    $scope.tid = "";
    var userid = "";
    var username = $window.UserName;
    $scope.closedTicket = "block";
    $scope.openTicketWindow = function ($event, t) {
        $scope.isDesc = true;
        $scope.title = t.Title;
        $scope.subject = t.Subject;
        $scope.tid = t.TicketId;
        userid = t.CreatedBy;
        $scope.ticketConversation = [];
        $scope.ddlStatus = [];




        $http.get(serviceUrl + "Admin/TicketsConversation?id=" + t.TicketId).then(function success(result) {
            console.log(t.TicketStatsId);
            if (t.TicketStatsId === 1) {
                $scope.selectedStatus = "open";
                $scope.closedTicket = "block";
            }
            else {
                $scope.selectedStatus = "close";
                $scope.closedTicket = "none";
            }


            $scope.ticketConversation = result.data;
            // selectStatus =;


        }, function error(result) {

            console.log(result);
        });


    }
    $scope.statusChange = function () {
        var statusid = 0;
        if ($scope.selectedStatus === "open") {
            statusid = 1;
            $scope.closedTicket = "block";
        } else {
            statusid = 3;
            $scope.closedTicket = "none";
        }
        var config = {
            params: {
                id: statusid,
                ticketid: $scope.tid,
                isAdmin: true
            }
        }
        $window.config = config;
        $http.get(serviceUrl + "Admin/statuschange", config).then(function success(result) {


        }, function error() {


        });

    };
    $scope.CategoryList = [];
    $http.get(serviceUrl + "Admin/Cat", $window.config).then(function success(result) {
        $scope.CategoryList = result.data;

    },
        function error(result) {

        }
    );

    $scope.statusList = [];
    $http.get(serviceUrl + "Admin/ts", $window.config).then(function success(result) {
        $scope.statusList = result.data;

    },
        function error(result) {

        }
    );


    $scope.priorityList = [];
    $http.get(serviceUrl + "Admin/TicketPriority").then(function success(result) {
        $scope.priorityList = result.data;

    },
        function error(result) {

        }
    );

  

    $scope.Categorydata = [];
  

    

    $(document).ready(function () {
        $scope.selectedCategoryChange();
        $scope.loadTickets();        
    });


    $scope.selectedCategoryChange = function () {

        $http.get(serviceUrl + "Admin/Categories").then(function success(result) {

            $scope.tickets = result.data.TicketDetails;
            $scope.OpenTickets = result.data.OpenTickets;
            $scope.InprogressTickets = result.data.inprogressTickets;
            $scope.ClosedTickets = result.data.ClosedTickets;
            
            angular.forEach(result.data.TicketDetails, function (value, key) {
                if (value.TicketStatsId == 1) {
                    $scope.openTickets = $filter('filter')(result.data.TicketDetails, { TicketStatsId: 1 });
                    updatePrevious0($scope.openTickets);

                   }
            });
            angular.forEach(result.data.TicketDetails, function (value, key) {
                if (value.TicketStatsId == 2) {
                    $scope.inProgressTickets = $filter('filter')(result.data.TicketDetails, { TicketStatsId: 2 });
                    updatePrevious($scope.inProgressTickets);
                }
            });



        }, function error() { });

      

    };
    var previous0 = [];
    var updatePrevious0 = function (newPrevious0) {
        angular.copy(newPrevious0, previous0);
    };

    updatePrevious0($scope.openTickets);

    $scope.$watch("openTickets", function (newValue, oldValue) {
        if (newValue != undefined && oldValue != undefined && newValue.length > oldValue.length) {

            if (newValue !== oldValue) {
                for (var i = 0; i < newValue.length; i++) {

                    if (angular.equals(newValue[i], previous0[i])) continue;


                    var changedEmployee0 = newValue[i].TicketId;
                    console.log('Changed employee:', changedEmployee0);

                    var index0 = newValue.indexOf(changedEmployee0);
                    console.log('Index:', index0);

                    updatePrevious0(newValue);

                    var config = {
                        params: {
                            id: 1,
                            ticketid: changedEmployee0
                        }
                    }

                    $http.get(serviceUrl + "Admin/UpdateStatus", config).then(function success(result) {

                        $scope.tickets = result.data;
                        if ($scope.tickets) {
                          
                            //$scope.selectedCategoryChange();
                            //$scope.$apply();
                            $window.location.reload();
                          
                        }

                    }, function error() { });

                }
            }
        }
    }, true);

    var previous = [];
    var updatePrevious = function (newPrevious) {
        angular.copy(newPrevious, previous);
    };
    updatePrevious($scope.inProgressTickets);


    $scope.$watch("inProgressTickets", function (newValue, oldValue) {
        if (newValue != undefined && oldValue != undefined && newValue.length > oldValue.length) {

            if (newValue !== oldValue) {
                for (var i = 0; i < newValue.length; i++) {

                    if (angular.equals(newValue[i], previous[i])) continue;


                    var changedEmployee = newValue[i].TicketId;
                    console.log('Changed employee:', changedEmployee);

                    var index = newValue.indexOf(changedEmployee);
                    console.log('Index:', index);

                    updatePrevious(newValue);

                    var config = {
                        params: {
                            id: 2,
                            ticketid: changedEmployee
                        }
                    }

                    $http.get(serviceUrl + "Admin/UpdateStatus", config).then(function success(result) {

                        $scope.tickets = result.data;
                        if ($scope.tickets) {
                            //$scope.$apply();
                            //$scope.selectedCategoryChange();
                            $window.location.reload();
                          
                        }

                    }, function error() { });
                }
            }
        }
    }, true);
  

  

    $scope.tcCreate = function () {
        var data = { TicketConversationId: 0, TicketId: $scope.tid, Description: $scope.des, UserName: username, ToId: userid, FromId: 2, CreatedDate: Date.now(), isAdmin: true };
        $http.post(serviceUrl + "Admin/TcCreate", data).then(function success(result) {

            $scope.ticketConversation.push(result.data);

            $scope.des = "";
            $scope.apply();
        }, function error() { });
    }
    $scope.SearchTickets = function () {
        
        var searchText = $scope.searchTicket  
        if (searchText != null) {
            $scope.edit = true;
            $scope.allTickets = $filter('filter')($scope.tickets, { TicketId: searchText });
            $scope.count = $scope.allTickets.length;
            $scope.countSpell = $scope.count > 1 ? "Tickets" : "Ticket";
            $scope.countName = "Serach Result";
            if ($scope.allTickets.length == 0) {
                $scope.allTickets = $filter('filter')($scope.tickets, { Company: searchText });
                $scope.count = $scope.allTickets.length;
                $scope.countSpell = $scope.count > 1 ? "Tickets" : "Ticket";
                $scope.countName = "Serach Result";
            }
            if ($scope.allTickets.length == 0) {
                $scope.allTickets = $filter('filter')($scope.tickets, { Category: searchText });
                $scope.count = $scope.allTickets.length;
                $scope.countSpell = $scope.count > 1 ? "Tickets" : "Ticket";
                $scope.countName = "Serach Result";
            }
        } 
        else {
            $scope.edit = false;
            $scope.openTickets = $filter('filter')(result.data.TicketDetails, { TicketStatsId: 1 });
            $scope.inProgressTickets == $filter('filter')(result.data.TicketDetails, { TicketStatsId: 2 });
        }
     
        if (!$scope.$$phase) {


            $scope.$apply();
        }
    };
    $scope.statusListChange = function (item) {
     
        $http.get(serviceUrl + "Admin/Categories").then(function success(result) {

            $scope.tickets = result.data.TicketDetails;
            $scope.OpenTickets = result.data.OpenTickets;
            $scope.InprogressTickets = result.data.inprogressTickets;
            $scope.ClosedTickets = result.data.ClosedTickets;

            angular.forEach(result.data.TicketDetails, function (value, key) {
                if (item == 1) {
                    $scope.allTickets = $filter('filter')(result.data.TicketDetails, { TicketStatsId: 1 });
                    $scope.count = $scope.allTickets.length;
                    $scope.countSpell = $scope.count > 1 ? "Tickets" : "Ticket";
                    $scope.countName = "Open";
                }
                else if (item == 2) {
                    $scope.allTickets = $filter('filter')(result.data.TicketDetails, { TicketStatsId: 2 });
                    $scope.count = $scope.allTickets.length;
                    $scope.countSpell = $scope.count > 1 ? "Tickets" : "Ticket";
                    $scope.countName = "In Progress";
                }
                else if (item == 3) {
                    $scope.allTickets = $filter('filter')(result.data.TicketDetails, { TicketStatsId: 3 });
                    $scope.count = $scope.allTickets.length;
                    $scope.countSpell = $scope.count > 1 ? "Tickets" : "Ticket";
                    $scope.countName = "Closed";
                }
                else {
                    $scope.allTickets = [];
                }
            });
          

        }, function error() { });

       

    };

    $scope.priorityChange = function (item) {

        $http.get(serviceUrl + "Admin/Categories").then(function success(result) {

            $scope.tickets = result.data.TicketDetails;
            $scope.OpenTickets = result.data.OpenTickets;
            $scope.InprogressTickets = result.data.inprogressTickets;
            $scope.ClosedTickets = result.data.ClosedTickets;

            angular.forEach(result.data.TicketDetails, function (value, key) {
                if (item == 1) {
                    $scope.allTickets = $filter('filter')(result.data.TicketDetails, { TicketPriorityId: 1 });
                    $scope.count = $scope.allTickets.length;
                    $scope.countSpell = $scope.count > 1 ? "Tickets" : "Ticket";
                    $scope.countName = "High Priority";
                }
                else if (item == 2) {
                    $scope.allTickets = $filter('filter')(result.data.TicketDetails, { TicketPriorityId: 2 });
                    $scope.count = $scope.allTickets.length;
                    $scope.countSpell = $scope.count > 1 ? "Tickets" : "Ticket";
                    $scope.countName = "Medium Priority";
                }
                else if (item == 3) {
                    $scope.allTickets = $filter('filter')(result.data.TicketDetails, { TicketPriorityId: 3 });
                    $scope.count = $scope.allTickets.length;
                    $scope.countSpell = $scope.count > 1 ? "Tickets" : "Ticket";
                    $scope.countName = "Low Priority";
                }
                else {
                    $scope.allTickets = [];
                }
            });


        }, function error() { });



    };

    $scope.linkWindow = function ($event, c) {
        var id = c.TicketId;
        $window.location = '/Admin/DescriptionPage?id=' + id;
       // $location.path("~/Admin/DescriptionPage");
       
    };

    function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }
    var id = getParameterByName('id');


    $scope.FilterByButton = function (button) {
        var statusid = 0;
        if (button === "close") {
            statusid = 3;
        }
        else {
            statusid = 1;
        }
        $filter('filter')(datat, { TicketStatsId: statusid });
    };

});
app.controller('descriptionController', function ($scope, $http, serviceUrl, $window, $filter, $location) {

    $(document).ready(function () {       
        $scope.loadTickets();
        $scope.loadTicketConv();
    });

    $scope.btnBackClick = function () {
        $window.location = '/Admin/TicketPage';
    };

    

    function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }
    var id = getParameterByName('id');
    $window.id = id;

    $scope.loadTickets = function () {
        $http.get(serviceUrl + "Admin/TicketsById?id=" + $window.id).then(function success(result) {
            $scope.tickets = result.data[0];
             $scope.TicketId  = $scope.tickets.TicketId;           
              $scope.Name = $scope.tickets.Name;
              $scope.Company = $scope.tickets.Company;
              $scope.Subject = $scope.tickets.Subject;
              $scope.ProductId = $scope.tickets.ProductId;
              $scope.CategoryId = $scope.tickets.CategoryId;
              $scope.SerialNumber = $scope.tickets.SerialNumber;
              $scope.TicketStatsId = $scope.tickets.TicketStatsId;
              $scope.TicketStatusCD = $scope.tickets.TicketStatsId == 1 ? "Open": $scope.tickets.TicketStatsId == 2 ? "Inprogress":"Closed";
              $scope.CreatedBy = $scope.tickets.CreatedBy;
              $scope.CreatedDate = $scope.tickets.CreatedDate;
              $scope.Email = $scope.tickets.Email;
              $scope.ImageValue = $scope.tickets.ImageValue;
              var PriorityList = $scope.tickets.TicketPriorityId;
              $scope.Priority = PriorityList == 1 ? 'High' : PriorityList == 2 ? 'Medium' : 'Low';
              $window.TicketStatsId = $scope.tickets.TicketStatsId;

              $window.UserName = $scope.tickets.UserName;
              $window.UserId = $scope.tickets.UserId;
              $window.IsAdmin = $scope.tickets.IsAdmin;

              if ($window.TicketStatsId){
                  $scope.statusList = [];
                  $http.get(serviceUrl + "Admin/ts", $window.config).then(function success(result) {
                      var finalList = $filter('filter')(result.data, { TicketStatsId: $window.TicketStatsId });
                      result.data.splice((finalList[0].TicketStatsId)-1,1);
                      $scope.statusList = result.data;

                  },
                      function error(result) {

                      }
                  );
              }
              
              

            //datat = result.data;
        },
            function error() {

            });
    };

    $scope.loadTicketConv = function () {
        $http.get(serviceUrl + "Admin/TicketConvById?id=" + $window.id).then(function success(result) {
            $scope.ticketConv = result.data;
            //CreatedBy
         

            //datat = result.data;
        },
            function error() {

            });
    };

   

    $scope.statusListChange = function (item) {

        var config = {
            params: {
                id: item,
                ticketid: $window.id               
            }
        }

        $http.get(serviceUrl + "Admin/UpdateStatus", config).then(function success(result) {

            $scope.tickets = result.data;
            if ($scope.tickets){
                $window.location.reload();
            }

        }, function error() { });

    };

   

    $scope.tcCreate = function () {
        if ($scope.description != null) {
            var data = { TicketConversationId: 0, TicketId: $window.id, Description: $scope.description, UserName: $window.UserName, ToId: 2, FromId: $window.UserId, CreatedDate: Date.now(), isAdmin: $window.IsAdmin };
            $http.post(serviceUrl + "Admin/TcCreate", data).then(function success(result) {

                if (data) {
                    $window.location.reload();
                }

                $scope.des = "";
                $scope.apply();
            }, function error() { });
        }
        else {

        }
    };

   
       

});
app.controller('dashBoardController', function ($scope, $http, serviceUrl, $window, $filter, $location) {
    
    $(document).ready(function () {
        $scope.statusListChange();       
    });


    $scope.statusListChange = function (item) {

        $http.get(serviceUrl + "Admin/Categories").then(function success(result) {
          
            $scope.OpenTickets = result.data.OpenTickets;
            $scope.InprogressTickets = result.data.inprogressTickets;
            $scope.ClosedTickets = result.data.ClosedTickets;
            $scope.allTickets = result.data.OpenTickets + result.data.inprogressTickets + result.data.ClosedTickets;


        }, function error() { });



    };

});

app.filter('firstletter', function () {
    return function (input) {
        return (!!input) ? input.charAt(0).toUpperCase() : '';
    }
});
// directive for dnd between lists
app.directive('dndBetweenList', function ($parse) {

    return function (scope, element, attrs) {

        // contains the args for this component
        var args = attrs.dndBetweenList.split(',');
        // contains the args for the target
        var targetArgs = $('#' + args[1]).attr('dnd-between-list').split(',');

        // variables used for dnd
        var toUpdate;
        var target;
        var startIndex = -1;
        var toTarget = true;

        // watch the model, so we always know what element
        // is at a specific position
        scope.$watch(args[0], function (value) {
            toUpdate = value;
        }, true);

        // also watch for changes in the target list
        scope.$watch(targetArgs[0], function (value) {
            target = value;
        }, true);

        // use jquery to make the element sortable (dnd). This is called
        // when the element is rendered
        $(element[0]).sortable({
            items: 'li',
            start: function (event, ui) {
                // on start we define where the item is dragged from
                startIndex = ($(ui.item).index());
                toTarget = false;
            },
            stop: function (event, ui) {
                var newParent = ui.item[0].parentNode.id;

                // on stop we determine the new index of the
                // item and store it there
                var newIndex = ($(ui.item).index());
                var toMove = toUpdate[startIndex];

                // we need to remove him from the configured model
                toUpdate.splice(startIndex, 1);

                if (newParent == args[1]) {
                    // and add it to the linked list
                    target.splice(newIndex, 0, toMove);
                } else {
                    toUpdate.splice(newIndex, 0, toMove);
                }

                // we move items in the array, if we want
                // to trigger an update in angular use $apply()
                // since we're outside angulars lifecycle
                if (targetArgs[0] == "openTickets" || targetArgs[0] == "inProgressTickets") {
                    //scope.$apply(args[0]);
                    setTimeout(function () {
                        scope.$apply(targetArgs[0]);
                        //scope.$apply(args[0]);
                    }, 1500);

                }
            },
            connectWith: '#' + args[1]
        })
    }
});