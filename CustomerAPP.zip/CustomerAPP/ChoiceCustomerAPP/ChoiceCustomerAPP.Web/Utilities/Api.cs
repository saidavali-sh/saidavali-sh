﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Web;

namespace ChoiceCustomerAPP.Web.Utilities
{
    public class Api
    {
        const string _baseUri = "http://cslsupportapi.azurewebsites.net/";
        public static string Post(string uri, object model)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(_baseUri);
               //  client.BaseAddress = new Uri("http://localhost:55466/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.PostAsync(uri, model, new JsonMediaTypeFormatter()).Result;
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    return "OK";
                }
            }
            return "fail";
        }

        public static string Get(string uri, Dictionary<string, string> param)
        {

            var parUri = "?";
            foreach (var item in param)
            {
                parUri = parUri + item.Key + "=" + item.Value + "&";
            }
           
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(_baseUri);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync(uri + parUri).Result;
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    return response.Content.ReadAsStringAsync().Result;
                }
                return "";
            }
        }


        public static string Get(string uri, object model)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(_baseUri);
                // client.BaseAddress = new Uri("http://localhost:55466/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.PostAsync(uri, model, new JsonMediaTypeFormatter()).Result;
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    return response.Content.ReadAsStringAsync().Result;
                }
            }
            return "";
        }
    }
}