﻿// App intialization for angular js
var app = angular.module('chat-app', ['ngRoute', 'luegg.directives']).run(function ($rootScope) {
    $rootScope.isReturn = false;
    $rootScope.isBottom = false;
    $rootScope.isHome = true;
    $rootScope.chat = false;
    $rootScope.ticket = false;
    $rootScope.call = false;
    $rootScope.isReturnlist = false;
    $rootScope.logout = function () {

        $rootScope.isReturn = false;
        $rootScope.isBottom = false;
        $rootScope.isReturnlist = false;
        window.localStorage.clear();
        window.location = "#index";
    };
});

//constant variables
app.constant('serviceUrl', 'http://cslsupportapi.azurewebsites.net/');
//app.constant('serviceUrl', 'http://localhost:55466/');
app.constant('serviceUrlLocal', 'http://localhost:50119/');

// route defining for app
app.config(function ($routeProvider) {

    $routeProvider.when("/", {
        templateUrl: "pages/login.html",
        controller: "loginController"
    }).when("/chat", {
        templateUrl: "pages/chat.html",
        controller: "ChatController"
    }).when("/main", {

        templateUrl: "pages/main.html",
        controller: "mainController"

    }).when("/ticket", {
        templateUrl: "pages/ticket.html",
        controller: "ticketController"
    }).when("/register", {

        templateUrl: "pages/register.html",
        controller: "registerController"
    }).when("/profile", {
        templateUrl: "pages/profile.html",
        controller: "profileController"
    }).when("/list", {
        templateUrl: "pages/ticketlist.html",
        controller: "ticketlistController"

    }).when("/view", {
        templateUrl: "pages/ticketview.html",
        controller: "ticketViewController"
        })
        .when("/description", {
            templateUrl: "pages/Description.html",
            controller: "descriptionController"
        }).otherwise({
        redirectTo: '/'
    });

});



// chat controller 
app.controller('ChatController', function ($scope, loginInfoService, $rootScope, serviceUrl, $http) {

    $(document).ready(function () {       
        window.scrollTo(0, document.body.scrollHeight);
    });   

  

    // scope variables
    $rootScope.isReturn = true;
    $rootScope.isBottom = true;
    $rootScope.isReturnlist = false;

    $rootScope.isHome = true;
    $rootScope.chat = false;
    $rootScope.ticket = false;
    $rootScope.call = false;


    /**/
    var chatqs = {
        qs: {
            userID: "",
            toGroupID: 2, //current active group/contact 
            defaultGroupID: "",  //logged in person default chat-groupId
            userName: ""
        }
    };
    var hubStarted = false;
    var userdata = loginInfoService.getInfo();
    chatqs.qs["userID"] = userdata.UserId;
    //chatqs.qs["toGroupID"]=use
    chatqs.qs["userName"] = userdata.UserName;
    $scope.username = userdata.UserName; // holds the user's name
    $scope.message = ''; // holds the new message

    $scope.messages = []; // collection of messages coming from server
    $scope.chatHub = null; // holds the reference to hub
    $.connection.hub.url = 'http://cslsupport.azurewebsites.net/signalr';
    //$.connection.hub.url = 'http://localhost:55400/signalr';

    $.connection.hub.qs = chatqs.qs;/**/
    $scope.chatHub = $.connection.chatHub; // initializes hub

    // register a client method on hub to be invoked by the server
    $scope.chatHub.client.broadcastMessage = function (name, message, isAdmin) {


        var newMessage = { msg: name + ':' + message, isAdmin: isAdmin };
        // push the newly coming message to the collection of messages
        $scope.messages.push(newMessage);
        $scope.$apply();
    };

    $.connection.hub.start().done(function () {
        hubStarted = true;



        var config = {
            params: {
                UserId: chatqs.qs["userID"],
                ToUserId: chatqs.qs["toGroupID"]
            }
        }
        $http.get(serviceUrl + "Admin/GetChat", config).then(function success(result) {

            angular.forEach(result.data, function (value, key) {
                var newMessage = { msg: value.CreatedBy + ':' + value.Text, isAdmin: value.isAdmin };
                // push the newly coming message to the collection of messages
                $scope.messages.push(newMessage);


               
            });
        },
            function error(result) {

            }
        );
        //$scope.chatHub.server.sendMessage($scope.username, $scope.message, false, chatqs.qs["toGroupID"]);
        // $scope.message = '';
    });


    $scope.newMessage = function () {


        if (hubStarted) {
            // Wire up Send button to call sendmessage on the server.
            $scope.chatHub.server.sendMessage($scope.username, $scope.message, false, chatqs.qs["toGroupID"],"");

            var newMessage = { msg: $scope.username + ':' + $scope.message, isAdmin: false };
            // push the newly coming message to the collection of messages
            $scope.messages.push(newMessage);
            //  $scope.$apply();
            $scope.message = '';
            // sends a new message to the server
        }
    };


});

//login controller
app.controller('loginController', function ($scope, $http, loginInfoService, serviceUrl, serviceUrlLocal, $rootScope) {
    $scope.username = ''
    $rootScope.isReturn = false;
    $rootScope.isReturnlist = false;
       

    $scope.offline = function () {

        var da = JSON.parse(window.localStorage.getItem("user"));

        if (da != null) {


            loginInfoService.addInfo(da);


            window.location = "#main";

        }

    }
    $scope.login = function () {


        var username = $scope.username
        var password = $scope.password

        var config = {
            params: {
                id: username,
                password: password
            }
        }
       
       
      


            $http.get(serviceUrl + "Admin/login", config).then(function successCallback(result) {

                if (result.statusText === "OK") {
                    
                    window.localStorage.setItem("user", JSON.stringify(result.data));

                    loginInfoService.addInfo(result.data);

                    window.location = "#main";
                }
                else {
                    console.log("failed");
                }
            },
                function errorCallback(result) {

                    console.log("failed");
                });
      
        

    }
});


//main controller
app.controller('mainController', function ($scope, $http, $rootScope, serviceUrl, loginInfoService) {
    $rootScope.isReturn = false;
    $rootScope.isBottom = true;
    $rootScope.isReturnlist = false;
    $rootScope.isHome = true;
    $rootScope.chat = false;
    $rootScope.ticket = false;
    $rootScope.call = false;
    //$(document).ready(function () {
    //    $scope.LoadProfile();
    //});

    //$scope.LoadProfile = function () {
    //    var userdata = loginInfoService.getInfo();
    //    $http.get(serviceUrl + "Admin/Profile?id=" + userdata.UserId).then(function success(result) {
    //        var d = result.data;

    //        $scope.filepreview = "data:image/png;base64," + d.ImageValue;


    //    }, function error() {

    //    });

    //};
    $scope.Call = function () {

        window.open("tel:+919010206767", "_system"); 
        window.open("tel:+919010206767", "_blank");
      
    };
})
// ticket Controller
app.controller("ticketController", function ($scope, $rootScope, $http, serviceUrl, serviceUrlLocal, loginInfoService) {

    $scope.ddlProduct = [];
    $scope.ddlCategory = [];
    $scope.ddlPriority = [];
    $rootScope.isBottom = true;
    $rootScope.isReturn = false;
    
    $rootScope.isReturnlist = true;

    $rootScope.isHome = true;
    $rootScope.chat = false;
    $rootScope.ticket = false;
    $rootScope.call = false;

    $scope.tname = "";
   
    $scope.tsubject = "";
    $scope.tselectedpro = "";
    $scope.tselectedCat = "";
    $scope.tselectedPriority = "";
    $scope.tdes = "";
    $scope.tsnumber = "";
    $scope.ttitle = "";
    
    $(document).ready(function () {    
        document.addEventListener("backbutton", onBackKeyDown, false);
    });

    function onBackKeyDown() {
        window.location = "#list";
    }
      
        var userdata = loginInfoService.getInfo();
       
        $scope.tphone = userdata.Phone;
        $scope.temail = userdata.Email;
        $scope.tcname = userdata.Company;
    $scope.LoadDropdown = function () {
      
        // to get the products
        $http.get(serviceUrl + "Admin/Products").then(function success(result) {

            var select = angular.copy(result.data[0]);
            select.ProductId = 0;
            select.ProductCD = "--Select--";
            result.data.push(select);
            $scope.ddlProduct = result.data;
        }, function error() {

        });

        // $scope.ddlCategory.push({CategoryCD:"--Select--",CategoryId:"0"})
        // to get the category
        $http.get(serviceUrl + "Admin/Cat").then(function success(result) {

            var select = angular.copy(result.data[0]);
            select.CategoryId = 0;
            select.CategoryCD = "--Select--";
            result.data.push(select);
            $scope.ddlCategory = result.data;

        }, function error() {
            console.log(result);
            });
        $http.get(serviceUrl + "Admin/TicketPriority").then(function success(result) {

            var select = angular.copy(result.data[0]);
            select.ID = 0;
            select.TicketPriorityCD = "--Select--";
            result.data.push(select);
            $scope.ddlPriority = result.data;

        }, function error() {
            console.log(result);
        });
        

      
    };
    $scope.createTicket = function () {


        // $scope.temail;



        var data = {
            Name: $scope.tname,
            Phone: $scope.tphone,
            Company: $scope.tcname,
            Subject: $scope.tsubject,
            ProductId: $scope.tselectedpro,
            CategoryId: $scope.tselectedCat,
            TicketPriorityId: $scope.tselectedPriority ? $scope.tselectedPriority:1,
            SerialNumber: $scope.tsnumber,
            Title: $scope.ttitle,
            TicketId: 0,
            Email: $scope.temail,
            UserName: userdata.UserName,
            TicketConverstations: [{ TicketConversationId: 0, TicketId: 0, Description: $scope.tdes, ToId: 2, FromId: userdata.UserId, isAdmin: false }]
        }
        $http.post(serviceUrl + "Admin/CreateTicket", data).then(function (result) {

            $scope.tname = "";
            $scope.tphone = "";
            $scope.temail = "";
            $scope.tcname = "";
            $scope.tsubject = "";
            $scope.tselectedpro = 0;
            $scope.tselectedCat = 0;
            $scope.tselectedPriority = 0;
            $scope.tdes = "";
            $scope.tsnumber = "";
            $scope.ttitle = "";
            window.location ="#list"
        });

    };

  
});
// register controller
app.controller("registerController", function ($scope, $rootScope, $http, serviceUrl, uploadService) {


    $rootScope.isReturn = false;
    $rootScope.isBottom = false;
    $scope.fname = "";
    $scope.lname = "";
    $scope.temail = "";
    $scope.tpassword = "";
    $scope.tcpassword = "";
    $scope.tphone = "";
    $scope.tcname = "";
    var ImageSource = null;
    $scope.newfile = null;
    $scope.oldfile = null;
    var pUserId = "";
    $scope.deviceUser = function () {


        var notificationOpenedCallback = function (jsonData) {
          
            console.log('notificationOpenedCallback: ' + JSON.stringify(jsonData));
        };

        window.plugins.OneSignal.startInit("2530a6a6-eeca-4fc5-9298-8228c9e99ff5").handleNotificationOpened(notificationOpenedCallback).endInit();

        window.plugins.OneSignal.getIds(function (ids) {
          
            pUserId = JSON.stringify(ids['userId']);
        });
    };
    $scope.register = function () {

        var data = {

            FirstName: $scope.fname,
            LastName: $scope.lname,
            Email: $scope.temail,
            Phone: $scope.tphone,
            Password: $scope.tpassword,
            Company: $scope.tcname,
            PushId: pUserId
        };


      


        $http.post(serviceUrl + "Admin/reg", data).then(function success(result) {


            var img = ImageSource;
            var user = result.data;
            uploadService.upload(img, user.UserId);
         
            window.location = "#/"
        }, function error() { });

    };

    // image upload code
    $scope.$watch('file', function (newfile, oldfile) {
        if (angular.equals(newfile, oldfile)) {
            return;
        }
        ImageSource = newfile;

    });

    $scope.EmailCheck = function () {

        $http.get(serviceUrl + "Admin/EmailCheck?id=" + $scope.temail).then(function success(result) {
           
            if (result.data === false) {
                $scope.userForm.temail.$setValidity("emailExist", false);
            }
           
        },
            function error(result) {
                console.log(result.data);

            });

    };
});

// profile controller
app.controller("profileController", function ($scope, $rootScope, $http, serviceUrl, loginInfoService, uploadService) {

    $rootScope.isReturn = true;
    $rootScope.isBottom = true;
    $rootScope.isReturnlist = false;

    $rootScope.isHome = false;
    $rootScope.chat = true;
    $rootScope.ticket = false;
    $scope.profile = null;



    $scope.pfname = ""

    $scope.plname = ""

    $scope.pnumber = ""

    $scope.pemail = ""

    $scope.pcompany = ""
    $scope.filepreview = "";
    var UserId = "";

    $scope.LoadProfile = function () {
        var userdata = loginInfoService.getInfo();
        $http.get(serviceUrl + "Admin/Profile?id=" + userdata.UserId).then(function success(result) {
            var d = result.data;

            $scope.pfname = d.FirstName;

            $scope.plname = d.LastName;

            $scope.pnumber = d.Phone;

            $scope.pemail = d.Email;
            UserId = d.UserId;
            $scope.pcompany = d.Company;
            $scope.filepreview = "data:image/png;base64," + d.ImageValue;
            window.ImageValue = $scope.filepreview;
            console.log(d.ImageValue);

        }, function error() {

        });

    };

    $scope.$watch('file', function (newfile, oldfile) {
        if (angular.equals(newfile, oldfile)) {
            return;
        }

        uploadService.upload(newfile, UserId);
    });

});

// ticket list controller
app.controller("ticketlistController", function ($scope, $rootScope, $http, serviceUrl, loginInfoService, TicketService, $filter, ticketStatus) {
    $rootScope.isReturn = true;
    $rootScope.isReturnlist = false;
    $rootScope.isBottom = true;
    // $scope.filterTicket = 0;

    $(document).ready(function () {
        $scope.loadAllTickets();
        document.addEventListener("backbutton", onBackKeyDown, false);
    });
   
    function onBackKeyDown() {
        window.location = "#main";
    }

    $scope.loadAllTickets = function () {
        //$scope.checked = true;
        var userdata = loginInfoService.getInfo();
        $http.get(serviceUrl + "Admin/TicketsByUser?id=" + userdata.UserId).then(function success(result) {

            $scope.tickets = result.data.TicketDetails;

        },
            function error() {

            });
    };


    $rootScope.isHome = true;
    $scope.tickets = [];
    var ticketsData = [];
    var userdata = loginInfoService.getInfo();
    $http.get(serviceUrl + "Admin/TicketsByUser?id=" + userdata.UserId).then(function success(result) {
       
        ticketsData = $scope.tickets = result.data.TicketDetails;       

    },
        function error() {

        });

    $scope.LoadticketData = function ($event, chat) {

        var id = chat.TicketId;
        window.location = '#description?id=' + id;
       
        //ticketStatus.addInfo(chat.TicketStatsId);

        //$http.get(serviceUrl + "Admin/TicketsConversation?id=" + chat.TicketId, ).then(function success(result) {
        //    TicketService.addInfo(result.data);
        //    window.location = "#view";

        //}, function error(result) {

        //    console.log(result);
        //});
    };

    $scope.filterTicket = function () {
        $scope.tickets = $filter('filter')(ticketsData, { TicketStatsId: $scope.selectedStatus });
        console.log($scope.tickets);
    };
});

// ticket view controller
app.controller("ticketViewController", function ($scope, $rootScope, $http, serviceUrl, loginInfoService, TicketService, ticketStatus, updateTicketStatus) {
    $rootScope.isReturn = false;
    $rootScope.isBottom = true;
    $rootScope.isReturnlist = true;
    $rootScope.isHome = true;
    $scope.messages = []
    $scope.message = "";
    $scope.statusTicket = ticketStatus.getInfo();
    $scope.showTexting = 'block';
    $scope.LoadTicket = function () {
        var data = TicketService.getInfo();
        $scope.messages = data;
        if ($scope.statusTicket === 3) {
            $scope.btnStatusText = "Re-open";
            $scope.showTexting = 'none';
        }
        else {
            $scope.btnStatusText = "close"
            $scope.showTexting = 'block';
        }
    };

    $scope.newMessage = function () {
        var userdata = loginInfoService.getInfo();
        var data = { TicketConversationId: 0, TicketId: $scope.messages[0].TicketId, Description: $scope.message, UserName: userdata.UserName, ToId: 2, FromId: userdata.UserId, CreatedDate: Date.now(), isAdmin: false };
        $http.post(serviceUrl + "Admin/TcCreate", data).then(function success(result) {
            console.log(result);
            var data = TicketService.getInfo();
            var d = angular.copy(data[0]);
            d.Description = result.data.Description;
            d.CreatedDate = result.data.CreatedDate;
            $scope.messages.push(d);
            $scope.message = "";

        }, function error() { });

    };

    $scope.updateStatus = function () {
        
        

        updateTicketStatus.update($scope);

    };

    $scope.ChangeTicketChange = function () {
       
    };

});

app.controller("descriptionController", function ($scope, $rootScope, $http, serviceUrl, loginInfoService, TicketService, ticketStatus, updateTicketStatus) {

    $rootScope.isReturn = false;
    $rootScope.isBottom = true;
    $rootScope.isReturnlist = true;
    $rootScope.isHome = true;

    $(document).ready(function () {
        $scope.loadTickets();
        $scope.loadTicketConv();
        document.addEventListener("backbutton", onBackKeyDown, false);
    });   

function onBackKeyDown() {
    window.location = "#list";
}


    function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }
    var id = getParameterByName('id');
    window.id = id;

    $scope.loadTickets = function () {
        $http.get(serviceUrl + "Admin/TicketsById?id=" + window.id, ).then(function success(result) {
            $scope.tickets = result.data[0];
            $scope.TicketId = $scope.tickets.TicketId;
            $scope.Name = $scope.tickets.Name;
            $scope.Company = $scope.tickets.Company;
            $scope.Subject = $scope.tickets.Subject;
            $scope.ProductId = $scope.tickets.ProductId;
            $scope.CategoryId = $scope.tickets.CategoryId;
            $scope.SerialNumber = $scope.tickets.SerialNumber;
            $scope.TicketStatsId = $scope.tickets.TicketStatsId;
            $scope.CreatedBy = $scope.tickets.CreatedBy;
            $scope.CreatedDate = $scope.tickets.CreatedDate;
            $scope.Email = $scope.tickets.Email;
            $scope.ImageValue = $scope.tickets.ImageValue;
            var PriorityList = $scope.tickets.TicketPriorityId;
            $scope.Priority = PriorityList == 1 ? 'High' : PriorityList == 2 ? 'Medium' : 'Low';
            window.TicketStatsId = $scope.tickets.TicketStatsId;

            window.UserName = $scope.tickets.UserName;
            window.UserId = $scope.tickets.UserId;
            window.IsAdmin = $scope.tickets.IsAdmin;





            //datat = result.data;
        },
            function error() {

            });
    };

    $scope.loadTicketConv = function () {
        $http.get(serviceUrl + "Admin/TicketConvById?id=" + window.id, ).then(function success(result) {
            $scope.ticketConv = result.data;
            //CreatedBy


            //datat = result.data;
        },
            function error() {

            });
    };



    $scope.statusListChange = function (item) {

        var config = {
            params: {
                id: item,
                ticketid: window.id
            }
        }

        $http.get(serviceUrl + "Admin/UpdateStatus", config).then(function success(result) {

            $scope.tickets = result.data;
            if ($scope.tickets) {
                window.location.reload();
            }

        }, function error() { });

    };

    $scope.statusList = [];
    $http.get(serviceUrl + "Admin/ts", window.config).then(function success(result) {
        //$scope.TicketStatsId = window.TicketStatsId;
        $scope.statusList = result.data;

    },
        function error(result) {

        }
    );

    $scope.tcCreate = function () {
        if ($scope.description != null) {
            var data = { TicketConversationId: 0, TicketId: window.id, Description: $scope.description, UserName: window.UserName, ToId: 2, FromId: window.UserId, CreatedDate: Date.now(), isAdmin: window.IsAdmin };
            $http.post(serviceUrl + "Admin/TcCreate", data).then(function success(result) {

                if (data) {
                    window.location.reload();
                }

                $scope.des = "";
                $scope.apply();
            }, function error() { });
        }
        else {

        }
    };




    //$rootScope.isReturn = false;
    //$rootScope.isBottom = true;
    //$rootScope.isReturnlist = true;
    //$rootScope.isHome = true;
    //$scope.messages = []
    //$scope.message = "";
    //$scope.statusTicket = ticketStatus.getInfo();
    //$scope.showTexting = 'block';
    //$scope.LoadTicket = function () {
    //    var data = TicketService.getInfo();
    //    $scope.messages = data;
    //    if ($scope.statusTicket === 3) {
    //        $scope.btnStatusText = "Re-open";
    //        $scope.showTexting = 'none';
    //    }
    //    else {
    //        $scope.btnStatusText = "close"
    //        $scope.showTexting = 'block';
    //    }
    //};

    //$scope.newMessage = function () {
    //    var userdata = loginInfoService.getInfo();
    //    var data = { TicketConversationId: 0, TicketId: $scope.messages[0].TicketId, Description: $scope.message, UserName: userdata.UserName, ToId: 2, FromId: userdata.UserId, CreatedDate: Date.now(), isAdmin: false };
    //    $http.post(serviceUrl + "Admin/TcCreate", data).then(function success(result) {
    //        console.log(result);
    //        var data = TicketService.getInfo();
    //        var d = angular.copy(data[0]);
    //        d.Description = result.data.Description;
    //        d.CreatedDate = result.data.CreatedDate;
    //        $scope.messages.push(d);
    //        $scope.message = "";

    //    }, function error() { });

    //};

    //$scope.updateStatus = function () {



    //    updateTicketStatus.update($scope);

    //};

    //$scope.ChangeTicketChange = function () {

    //};

});


// login infor service
app.service('loginInfoService', function () {
    var loginInfo = null;

    var addInfo = function (result) {
        loginInfo = result;
    };

    var getInfo = function () {
        return loginInfo;
    };

    return {
        addInfo: addInfo,
        getInfo: getInfo
    };

});



//ticket service
app.service('TicketService', function () {
    var ticketInfo = null;

    var addInfo = function (result) {
        ticketInfo = result;
    };

    var getInfo = function () {
        return ticketInfo;
    };

    return {
        addInfo: addInfo,
        getInfo: getInfo
    };

});


// ticket Status
app.service('ticketStatus', function () {
    var ticketStatus = null;

    var addInfo = function (result) {
        ticketStatus = result;
    };

    var getInfo = function () {
        return ticketStatus;
    };

    return {
        addInfo: addInfo,
        getInfo: getInfo
    };

});



// upload service
app.service("uploadService", function ($http, serviceUrl) {

    return ({
        upload: upload
    });

    function upload(file, userid) {

        if (file) {
            var reader = new FileReader();

            reader.onload = function (readerEvt) {
                var binaryString = readerEvt.target.result;
                var txt = btoa(binaryString);



                var data = {
                    image: txt,
                    id: userid
                };
                console.log(userid);
                console.log(txt);
                $http.post(serviceUrl + "Admin/PostImage", data).then(function success(result) {

                    console.log(result.data);

                });

            };

            reader.readAsBinaryString(file);
        }




    } // End upload function


});



app.service("updateTicketStatus", function ($http,serviceUrl) {

    return ({
        update: update
    });
    function update(scope)
    {
        var statuid = 0;
        if (scope.btnStatusText === "close") {
            statuid = 3;

            scope.showTexting = 'none';
            scope.btnStatusText = "Re-open";

        }
        else {
            statuid = 1;

            scope.showTexting = 'block';
            scope.btnStatusText = "close";

        }

        var config = {
            params: {
                id: statuid,
                ticketid: scope.messages[0].TicketId,
                isAdmin: false
            }
        }
        $http.get(serviceUrl + "Admin/statuschange", config).then(function success(result) {




            //}
        }, function error() {


        });

    }



});

// to compare the password
app.directive("compareTo", function () {

    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function (scope, element, attributes, ngModel) {

            ngModel.$validators.compareTo = function (modelValue) {
                return modelValue === scope.otherModelValue;
            };

            scope.$watch("otherModelValue", function () {
                ngModel.$validate();
            });
        }
    };

});

// Image upload directive
app.directive("fileinput", [function () {
    return {
        scope: {
            fileinput: "=",
            filepreview: "="
        },
        link: function (scope, element, attributes) {
            element.bind("change", function (changeEvent) {
                scope.fileinput = changeEvent.target.files[0];
                var reader = new FileReader();
                reader.onload = function (loadEvent) {
                    scope.$apply(function () {
                        scope.filepreview = loadEvent.target.result;
                    });
                }
                reader.readAsDataURL(scope.fileinput);
            });
        }
    }
}]);

// email exist check directive

app.directive('emailExits', function ($timeout, $q) {
    return {
        restrict: 'AE',
        require: 'ngModel',
        link: function (scope, elm, attr, model) {
            model.$asyncValidators.usernameExists = function () {

                //here you should access the backend, to check if username exists
                //and return a promise
                //here we're using $q and $timeout to mimic a backend call 
                //that will resolve after 1 sec

                var defer = $q.defer();
                $timeout(function () {
                    model.$setValidity('emailExists', false);
                    defer.resolve;
                }, 1000);
                return defer.promise;
            };
        }
    }
});

app.directive('schrollBottom', function () {
    return {
        scope: {
            schrollBottom: "="
        },
        link: function (scope, element) {
            scope.$watchCollection('schrollBottom', function (newValue) {
                if (newValue) {
                    $(element).scrollTop($(element)[0].scrollHeight);
                }
            });
        }
    }
})