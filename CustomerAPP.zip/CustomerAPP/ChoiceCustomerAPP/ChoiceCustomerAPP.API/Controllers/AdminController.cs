﻿using ChoiceCustomerAPP.API.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Net.Mail;
namespace ChoiceCustomerAPP.API.Controllers
{
    [RoutePrefix("Admin")]
    public class AdminController : ApiController
    {
       
        public class TicketSummary
        {
            public List<TicketDetails> TicketDetails { get; set; }
            public int OpenTickets { get; set; }
            public int inprogressTickets { get; set; }
            public int ClosedTickets { get; set; }

        }

        public class TicketDetails
        {
            public long TicketId { get; set; }
            public string Subject { get; set; }
            public int TicketStatsId { get; set; }
            public long TicketConversationId { get; set; }

            public string Company { get; set; }
            public string Category { get; set; }

            public byte[] ImageValue { get; set; }
            public int TicketPriorityId { get; set; }
            public string CssIconClass { get; set; }
            public string CssClass { get; set; }

            

        public int TicketConversationCount { get; set; }
        }

        [Route("login")]
        [HttpGet]
        public HttpResponseMessage UserLogin(string id, string password)
        {
            try
            {

                using (var db = new ChatDBEntities())
                {

                    var result = (from u in db.ChatUsers
                                  where u.UserName == id && u.Password == password
                                  select new
                                  {

                                      u.UserId,
                                      u.UserName,
                                      u.IsAdmin,
                                      u.Email,
                                      u.Phone,
                                      u.Company

                                  }).FirstOrDefault();
                    if (result != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, result);
                    }

                }
                return Request.CreateResponse(HttpStatusCode.NoContent, HttpStatusCode.NoContent);
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }

        [Route("Insert")]
        [HttpPost]
        public HttpResponseMessage InsertChat(Message msg)
        {
            try
            {
                using (var db = new ChatDBEntities())
                {

                    var result = db.ChatConversations.Add(new ChatConversation
                    {
                        FromId = msg.FromGroupId,
                        ToId = msg.ToGroupId,
                        Text = msg.Text,
                        CreatedBy = msg.UserName,
                        CreatedDate = DateTime.Now,
                        isAdmin = msg.isAdmin
                    });
                    db.SaveChanges();


                }
                return Request.CreateResponse(HttpStatusCode.OK, HttpStatusCode.OK.ToString());
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }

        [Route("GetChat")]
        [HttpGet]
        public HttpResponseMessage GetChat(string UserId, string ToUserId)
        {
            try
            {
                using (var db = new ChatDBEntities())
                {
                    var userid = int.Parse(UserId);
                    var touserid = int.Parse(ToUserId);

                    var result = (from ct in db.ChatConversations where ct.FromId == userid && ct.ToId == touserid select ct).ToList();
                    var resultT = (from ct in db.ChatConversations where ct.FromId == touserid && ct.ToId == userid select ct).ToList();

                    result.AddRange(resultT);
                    return Request.CreateResponse(HttpStatusCode.OK, result.OrderBy(i => i.CreatedDate));
                }

            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }

        [Route("GetClients")]
        [HttpGet]
        public HttpResponseMessage GetAllClients()
        {
            try
            {
                using (var db = new ChatDBEntities())
                {
                    var result = (from us in db.ChatUsers where us.IsAdmin == false select us).ToList();

                    foreach (var item in result)
                    {
                        var msg = db.ChatConversations.ToList().Where(i => i.FromId == item.UserId).OrderByDescending(i => i.CreatedDate).FirstOrDefault();
                        if (msg != null)
                        {
                            result[result.IndexOf(item)].FirstName = !string.IsNullOrEmpty(msg.Text) ? msg.Text : "";
                            result[result.IndexOf(item)].CreatedDate = msg.CreatedDate.HasValue ? msg.CreatedDate : null;
                        }
                        else
                        {
                            result[result.IndexOf(item)].FirstName = "";
                            result[result.IndexOf(item)].CreatedDate = null;
                        }
                    }


                    return Request.CreateResponse(HttpStatusCode.OK, result.OrderByDescending(i => i.CreatedDate));
                }
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }


        [Route("loginAdmin")]
        [HttpPost]
        public HttpResponseMessage UserLoginAdmin(Login model)
        {
            try
            {

                using (var db = new ChatDBEntities())
                {

                    var result = (from u in db.ChatUsers
                                  where u.UserName == model.UserName && u.Password == model.Password && u.IsAdmin==true
                                  select new
                                  {

                                      u.UserId,
                                      u.UserName,
                                      u.IsAdmin

                                  }).FirstOrDefault();
                    if (result != null)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK, result);
                    }

                }
                return Request.CreateResponse(HttpStatusCode.NoContent, HttpStatusCode.NoContent);
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }

        [Route("Products")]
        [HttpGet]
        public HttpResponseMessage GetProducts()
        {
            try
            {

                using (var db = new ChatDBEntities())
                {
                    var result = (from p in db.Products
                                  select new
                                  {
                                      p.ProductId,
                                      p.ProductCD
                                  }).ToList();
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }


        [Route("Cat")]
        [HttpGet]
        public HttpResponseMessage GetCat()
        {
            try
            {

                using (var db = new ChatDBEntities())
                {
                    var result = (from p in db.Categories
                                  select new
                                  {
                                      p.CategoryId,
                                      p.CategoryCD
                                  }).ToList();
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }

        //[Route("Categories")]
        //[HttpGet]
        //public HttpResponseMessage GetCatById()
        //{
        //    try
        //    {

        //        using (var db = new ChatDBEntities())
        //        {
        //            //var result = (from cat in db.Categories.Where(x => x.CategoryId == CategoryId).ToList()
        //            //              join tkt in db.Tickets.ToList() on cat.CategoryId equals tkt.CategoryId
        //            //              join tktStatus in db.TicketStatus.ToList() on tkt.TicketStatsId equals tktStatus.TicketStatsId
        //            //              join tktconv in db.TicketConversations.ToList() on tkt.TicketId equals tktconv.TicketId
        //            //              select new
        //            //              {
        //            //                 tkt.TicketStatsId,
        //            //                 tkt.Subject,
        //            //                 tkt.TicketId
        //            //                 //tktconv.TicketConversationId,
        //            //              }).ToList();


        //            var temp = (from c in db.Categories
        //                        join t in db.Tickets on c.CategoryId equals t.CategoryId
        //                        join ts in db.TicketStatus on t.TicketStatsId equals ts.TicketStatsId
        //                        join tc in db.TicketConversations on t.TicketId equals tc.TicketId
        //                        select new
        //                        {
        //                            ts.TicketStatsId,
        //                            t.Subject,
        //                            t.TicketId,
        //                            t.Company,
        //                            t.Category
        //                        }).ToList();

        //            var group = (from t in temp
        //                         group t by t.TicketId into g
        //                         select new TicketDetails
        //                         {
        //                             TicketId = g.Key,
        //                             Subject = g.Select(x => x.Subject).First(),
        //                             TicketStatsId = g.Select(x => x.TicketStatsId).First(),
        //                             TicketConversationCount=g.Count(),
        //                             Company = g.Select(x => x.Company).First(),
        //                             Category = g.Select(x => x.Category.CategoryCD).First()
        //                             //TicketConversationId = g.Key
        //                         }).Distinct().ToList();

        //            var ticketStatusCount= new TicketSummary {
        //                TicketDetails= group,
        //                OpenTickets = group.Count(x => x.TicketStatsId == 1),
        //                inprogressTickets = group.Count(x => x.TicketStatsId == 2),
        //                ClosedTickets = group.Count(x => x.TicketStatsId == 3)
        //            };
        //            //var temp=from t in db.Tickets
        //            //         join tc in db.TicketConversations on t.TicketId equals tc.TicketId
        //            //         select new  

        //            return Request.CreateResponse(HttpStatusCode.OK, ticketStatusCount);
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
        //    }
        //}
        [Route("Categories")]
        [HttpGet]
        public HttpResponseMessage GetCatById()
        {
            try
            {

                using (var db = new ChatDBEntities())
                {

                    var temp = (from t1 in db.Tickets
                                  join t2 in db.ChatUsers on t1.CreatedBy equals t2.UserId
                                  join t3 in db.Products on t1.ProductId equals t3.ProductId
                                  join ts in db.TicketStatus on t1.TicketStatsId equals ts.TicketStatsId
                                  join tp in db.TicketPriorities on t1.TicketPriorityId equals tp.ID
                                  join t4 in db.TicketConversations on t1.TicketId equals t4.TicketId into con
                                  select new
                                  {
                                      t1.TicketId,
                                      t1.Company,
                                      t1.Category,
                                      t1.Subject,
                                      t1.Name,
                                      t2.ImageValue,
                                      t3.ProductCD,
                                      ts.TicketStatsId,
                                      tp.CssClass,
                                      tp.CssIconClass,
                                      tp.ID,
                                      Counts = con.Count()
                                  }).ToList();

                    var group = (from t in temp
                                 group t by t.TicketId into g
                                 select new TicketDetails
                                 {
                                     TicketId = g.Key,
                                     Subject = g.Select(x => x.Subject).First(),
                                     TicketStatsId = g.Select(x => x.TicketStatsId).First(),
                                     TicketPriorityId = g.Select(x => x.ID).First(),
                                     CssIconClass = g.Select(x => x.CssIconClass).First(),
                                     CssClass = g.Select(x => x.CssClass).First(),
                                     TicketConversationCount = g.Select(x => x.Counts).First(),
                                     Company = g.Select(x => x.Company).First(),
                                     Category = g.Select(x => x.Category.CategoryCD).First(),
                                     ImageValue = g.Select(x=>x.ImageValue).First()
                                    
                                 }).Distinct().ToList();

                    var ticketStatusCount = new TicketSummary
                    {
                        TicketDetails = group,
                        OpenTickets = group.Count(x => x.TicketStatsId == 1),
                        inprogressTickets = group.Count(x => x.TicketStatsId == 2),
                        ClosedTickets = group.Count(x => x.TicketStatsId == 3)
                    };




                    return Request.CreateResponse(HttpStatusCode.OK, ticketStatusCount);
                }
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }

        [Route("TicketsById")]
        [HttpGet]
        public HttpResponseMessage TicketsById(long id)
        {
            try
            {

                using (var db = new ChatDBEntities())
                {
                   
                    var temp = (from t in db.Tickets.Where(x => x.TicketId == id)
                                join t2 in db.ChatUsers on t.CreatedBy equals t2.UserId
                                select new
                                {
                                    t.TicketId,
                                    t.Name,
                                    t.Phone,
                                    t.Company,
                                    t.Subject,
                                    t.ProductId,
                                    t.CategoryId,
                                    t.SerialNumber,
                                    t.CreatedBy,
                                    t.CreatedDate,
                                    t.TicketStatsId,
                                    t.Title,
                                    t.Email,
                                    t2.ImageValue,
                                    t2.UserId,
                                    t2.UserName,
                                    t2.IsAdmin,
                                    t.TicketPriorityId
                                 
                                }).ToList();
                                   

                    return Request.CreateResponse(HttpStatusCode.OK, temp);
                }
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }

        [Route("TicketConvById")]
        [HttpGet]
        public HttpResponseMessage TicketConvById(long id)
        {
            try
            {

                using (var db = new ChatDBEntities())
                {

                    var temp = (from t in db.TicketConversations.Where(x => x.TicketId == id)
                                  
                                select new
                                {
                                    t.TicketConversationId,
                                    t.CreatedBy,
                                    t.CreatedDate,
                                    t.Description                                   

                                }).OrderByDescending(x=>x.CreatedDate).ToList();


                    return Request.CreateResponse(HttpStatusCode.OK, temp);
                }
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }

        [Route("CreateTicket")]
        [HttpPost]
        public HttpResponseMessage CreateTicket(Ticket tc)
        {
            try
            {
                using (var db = new ChatDBEntities())
                {
                    var tcs = tc.TicketConverstations.FirstOrDefault();
                    var etc = new Data.Ticket
                    {

                        Name = tc.Name,
                        Phone = tc.Phone,
                        CategoryId = tc.CategoryId,
                        ProductId = tc.ProductId,
                        Company = tc.Company,
                        SerialNumber = tc.SerialNumber,
                        TicketStatsId = 1,
                        CreatedDate = DateTime.Now,
                        Subject = tc.Subject,
                        CreatedBy = tcs.FromId,
                        Email = tc.Email,
                        Title = tc.Title,
                        TicketPriorityId = tc.TicketPriorityId

                    };
                    db.Tickets.Add(etc);
                    db.TicketConversations.Add(new Data.TicketConversation
                    {

                        Description = tcs.Description,
                        FromId = tcs.FromId,
                        ToId = tcs.ToId,
                        TicketId = etc.TicketId,
                        CreatedBy = tc.UserName,
                        CreatedDate = DateTime.Now,
                        isAdmin = tcs.isAdmin
                    });
                    db.SaveChanges();
                }
                return Request.CreateResponse(HttpStatusCode.OK, HttpStatusCode.OK.ToString());
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }
        [Route("Tickets")]
        [HttpGet]
        public HttpResponseMessage GetTickets()
        {
            try
            {
                using (var db = new ChatDBEntities())
                {
                    var result = (from t in db.Tickets select t).ToList();
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }


        //[Route("Tickets")]
        //[HttpGet]
        //public HttpResponseMessage GetTickets()
        //{
        //    try
        //    {
        //        using (var db = new ChatDBEntities())
        //        {
        //            var result = (from t in db.Tickets select t).ToList();
        //            return Request.CreateResponse(HttpStatusCode.OK, result);
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
        //    }
        //}


        [Route("TicketsConversation")]
        [HttpGet]
        public HttpResponseMessage GetTicketConversation(string id)
        {
            try
            {
                using (var db = new ChatDBEntities())
                {
                    var tid = int.Parse(id);
                    var result = (from tcs in db.TicketConversations where tcs.TicketId == tid select tcs).ToList();
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.OK, ex.Message, ex);
            }
        }
        [Route("TcCreate")]
        [HttpPost]
        public HttpResponseMessage CreateTicketConversation(TicketConversation tcs)
        {
            try
            {
                using (var db = new ChatDBEntities())
                {
                    var result = db.TicketConversations.Add(new Data.TicketConversation
                    {
                        Description = tcs.Description,
                        TicketId = tcs.TicketId,
                        ToId = tcs.ToId,
                        FromId = tcs.FromId,
                        CreatedBy = tcs.UserName,
                        CreatedDate = DateTime.Now,
                        isAdmin = tcs.isAdmin

                    });
                    tcs.CreatedDate = DateTime.Now;
                    db.SaveChanges();
                    // SendMail(tcs.Description,tcs.TicketId,tcs.UserName);
                    return Request.CreateResponse(HttpStatusCode.OK, tcs);
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.OK, ex.Message, ex);
            }
        }

        private void SendMail(string description, int ticketID, string userName)
        {
            using (var db = new ChatDBEntities())
            {
                var result = (from u in db.ChatUsers
                              where u.IsAdmin == true
                              select new
                              {
                                  u.Email

                              }).FirstOrDefault();

                MailMessage mail = new MailMessage();
                mail.To.Add(result.Email);
                mail.Body = "Following User  " + userName + " Ticket Information " + description + " Tickt:" + ticketID.ToString();
                mail.Subject = " Ticket Information:" + ticketID.ToString();
                mail.BodyEncoding = System.Text.Encoding.UTF8;
                mail.IsBodyHtml = true;
                mail.Priority = MailPriority.High;
                SmtpClient client = new SmtpClient();
                client.Credentials = new System.Net.NetworkCredential("from gmail address", "your gmail account password");
                client.Port = 587;
                client.Host = "smtp.gmail.com";
                client.EnableSsl = true;
                try
                {
                    client.Send(mail);
                }
                catch (Exception ex)
                {
                    throw ex.InnerException;
                }
            }

        }
        //  [Route("SendMail")]
        // [HttpGet]
        public void SendMailUserCreation(string toEmail, string name)
        {


            MailMessage mail = new MailMessage();

            // mail.To.Add(toEmail);
            mail.To.Add(toEmail);
            mail.Body = "Dear " + name + "<br/> Your registaration process completed successfully, please find the login details below.<br/><br/><br/> User Name: " + toEmail + "<br/><br/> Regards,<br/>csl support.";
            mail.Subject = "Registration Completed successfully!!";
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.From = new MailAddress("cslsupport@choice-solutions.com");
            mail.Priority = MailPriority.High;

            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("cslsupport@choice-solutions.com", "csl#1234");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            // client.UseDefaultCredentials = false;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            try
            {
                client.Send(mail);
                client.Dispose();
                mail.Dispose();
            }
            catch (Exception ex)
            {
                client.Dispose();
                mail.Dispose();
                throw ex.InnerException;
            }
            //return Request.CreateResponse(HttpStatusCode.OK,HttpStatusCode.OK.ToString());


        }
        [Route("ts")]
        [HttpGet]
        public HttpResponseMessage GetTicketStatus()
        {
            try
            {
                using (var db = new ChatDBEntities())
                {
                    var result = (from tks in db.TicketStatus
                                  select new
                                  {

                                      tks.TicketStatsId,
                                      tks.TicketStatusCD
                                  }).ToList();

                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.OK, ex.Message, ex);
            }
        }

        [Route("TicketPriority")]
        [HttpGet]
        public HttpResponseMessage GetTicketPriority()
        {
            try
            {
                using (var db = new ChatDBEntities())
                {
                    var result = (from tks in db.TicketPriorities
                                  select new
                                  {

                                      tks.ID,
                                      tks.TicketPriorityCD
                                  }).ToList();

                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.OK, ex.Message, ex);
            }
        }

        [Route("reg")]
        [HttpPost]
        public HttpResponseMessage Register(Register tcs)
        {
            try
            {
                using (var db = new ChatDBEntities())
                {
                    var cht = new ChatUser
                    {
                        UserName = tcs.Email,
                        FirstName = tcs.FirstName,
                        LastName = tcs.LastName,
                        Company = tcs.Company,
                        Phone = tcs.Phone,
                        Password = tcs.Password,
                        IsAdmin = false,
                        Email = tcs.Email,
                        CreatedBy = tcs.FirstName,
                        CreatedDate = DateTime.Now,
                        PushId=tcs.PushId
                        
                    };
                    var result = db.ChatUsers.Add(cht);

                    db.SaveChanges();
                    SendMailUserCreation(tcs.Email, tcs.FirstName + " " + tcs.LastName);
                    return Request.CreateResponse(HttpStatusCode.OK, cht);
                }
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }


        [Route("Profile")]
        [HttpGet]
        public HttpResponseMessage GetProfile(string id)
        {
            try
            {
                using (var db = new ChatDBEntities())
                {
                    var uid = int.Parse(id);
                    var result = (from tcs in db.ChatUsers where tcs.UserId == uid select tcs).FirstOrDefault();
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.OK, ex.Message, ex);
            }
        }


        [Route("TicketsByUser")]
        [HttpGet]
        public HttpResponseMessage GetTicketsByUser(string id)
        {
            //try
            //{
            //    using (var db = new ChatDBEntities())
            //    {
            //        var userid = int.Parse(id);
            //        var result = (from t in db.Tickets where t.CreatedBy == userid select t).ToList();
            //        return Request.CreateResponse(HttpStatusCode.OK, result);
            //    }
            //}
         try
            {

                using (var db = new ChatDBEntities())
                {
                    var userid = int.Parse(id);
                    var temp = (from t1 in db.Tickets
                                join t2 in db.ChatUsers on t1.CreatedBy equals t2.UserId
                                join t3 in db.Products on t1.ProductId equals t3.ProductId
                                join ts in db.TicketStatus on t1.TicketStatsId equals ts.TicketStatsId
                                join tp in db.TicketPriorities on t1.TicketPriorityId equals tp.ID
                                join t4 in db.TicketConversations on t1.TicketId equals t4.TicketId into con
                                where t1.CreatedBy == userid
                                select new
                                {
                                    t1.TicketId,
                                    t1.Company,
                                    t1.Category,
                                    t1.Subject,
                                    t1.Name,
                                    t2.ImageValue,
                                    t3.ProductCD,
                                    ts.TicketStatsId,
                                    tp.CssClass,
                                    tp.CssIconClass,
                                    tp.ID,
                                    Counts = con.Count()
                                }).ToList();

                    var group = (from t in temp
                                 group t by t.TicketId into g
                                 select new TicketDetails
                                 {
                                     TicketId = g.Key,
                                     Subject = g.Select(x => x.Subject).First(),
                                     TicketStatsId = g.Select(x => x.TicketStatsId).First(),
                                     TicketPriorityId = g.Select(x => x.ID).First(),
                                     CssIconClass = g.Select(x => x.CssIconClass).First(),
                                     CssClass = g.Select(x => x.CssClass).First(),
                                     TicketConversationCount = g.Select(x => x.Counts).First(),
                                     Company = g.Select(x => x.Company).First(),
                                     Category = g.Select(x => x.Category.CategoryCD).First(),
                                     ImageValue = g.Select(x => x.ImageValue).First()

                                 }).Distinct().ToList();

                    var ticketStatusCount = new TicketSummary
                    {
                        TicketDetails = group,
                        OpenTickets = group.Count(x => x.TicketStatsId == 1),
                        inprogressTickets = group.Count(x => x.TicketStatsId == 2),
                        ClosedTickets = group.Count(x => x.TicketStatsId == 3)
                    };




                    return Request.CreateResponse(HttpStatusCode.OK, ticketStatusCount);
                }
            }

            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }

        [Route("statuschange")]
        [HttpGet]
        public HttpResponseMessage ChangeStatus(string id, string ticketid, bool isAdmin)
        {
            try
            {
                var statusid = int.Parse(id);
                var tickeid = int.Parse(ticketid);
                using (var db = new ChatDBEntities())
                {
                    var result = db.Tickets.FirstOrDefault(i => i.TicketId == tickeid);
                    result.TicketStatsId = statusid;
                    db.SaveChanges();
                    if (isAdmin)
                    {
                        var clientDetails = db.ChatUsers.FirstOrDefault(i => i.UserId == result.CreatedBy);
                        SendMaildStatusUpdate(clientDetails.Email, clientDetails.FirstName + " " + clientDetails.LastName, result.TicketStatsId);
                    }
                    return Request.CreateResponse(HttpStatusCode.OK, HttpStatusCode.OK.ToString());
                }

            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);

            }
        }
        [Route("UpdateStatus")]
        [HttpGet]
        public HttpResponseMessage UpdateStatus(int id,long ticketid)
        {
            try
            {            
                using (var db = new ChatDBEntities())
                {
                    var result = db.Tickets.FirstOrDefault(i => i.TicketId == ticketid);
                    result.TicketStatsId = id;
                    db.SaveChanges();                   
                    return Request.CreateResponse(HttpStatusCode.OK, HttpStatusCode.OK.ToString());
                }

            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);

            }
        }

        [Route("PostImage")]
        [HttpPost]
        public HttpResponseMessage PostImage(UserImage usr)
        {
            try
            {
                using (var db = new ChatDBEntities())
                {

                    var result = db.ChatUsers.FirstOrDefault(i => i.UserId == usr.id);
                    if (result != null)
                    {
                        result.ImageValue = !string.IsNullOrEmpty(usr.image) ? Convert.FromBase64String(usr.image) : null;
                        db.SaveChanges();
                    }

                }
                return Request.CreateResponse(HttpStatusCode.OK, HttpStatusCode.OK.ToString());
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }

        public void SendMaildStatusUpdate(string toEmail, string name, int? statusid)
        {
            var statusText = "";
            if (statusid == 1)
            {
                statusText = "open";
            }
            else
            {
                statusText = "closed";
            }

            MailMessage mail = new MailMessage();

            // mail.To.Add(toEmail);
            mail.To.Add(toEmail);
            mail.Body = "Dear " + name + "<br/> Your ticket status changed to <b>" + statusText + "</b> successfully<br/><br/> Regards,<br/>csl support.";
            mail.Subject = "Ticket Status Change!!";
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.From = new MailAddress("cslsupport@choice-solutions.com");
            mail.Priority = MailPriority.High;

            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("cslsupport@choice-solutions.com", "csl#1234");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            // client.UseDefaultCredentials = false;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            try
            {
                client.Send(mail);
                client.Dispose();
                mail.Dispose();
            }
            catch (Exception ex)
            {
                client.Dispose();
                mail.Dispose();
                throw ex.InnerException;
            }
            //return Request.CreateResponse(HttpStatusCode.OK,HttpStatusCode.OK.ToString());


        }
        [HttpGet]
        [Route("EmailCheck")]
        public HttpResponseMessage CheckEmail(string id)
        {
            try
            {
                using (var db = new ChatDBEntities())
                {


                    var result = db.ChatUsers.Where(i => i.Email == id).ToList();
                    var isEmail = false;
                    if (result.Count == 0)
                    {
                        isEmail = true;
                    }
                    else
                    {
                        isEmail = false;
                    }
                    return Request.CreateResponse(HttpStatusCode.OK, isEmail);
                }
            }
            catch (Exception ex)
            {

                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message, ex);
            }
        }
    }


    #region Models
    public class Message
    {
        public long MessageId { get; set; }

        public string UserName { get; set; }
        public int UserId { get; set; }

        public string Text { get; set; }
        public DateTime? TimeStamp { get; set; }
        public bool Isme { get; set; } //set when message belongs to current user

        public int FromGroupId { get; set; }
        public int ToGroupId { get; set; }
        public bool isAdmin { get; set; }
    }

    public class Login
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool isAdmin { get; set; }
    }

    public class Ticket
    {
        public int TicketId { get; set; }
        public string Title { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Company { get; set; }
        public string Subject { get; set; }
        public int ProductId { get; set; }
        public int CategoryId { get; set; }
        public string SerialNumber { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public int TicketPriorityId { get; set; }

        public List<TicketConversation> TicketConverstations { get; set; }
    }

    public class TicketConversation
    {
        public int TicketConversationId { get; set; }
        public string Description { get; set; }

        public int ToId { get; set; }
        public int FromId { get; set; }
        public int TicketId { get; set; }
        public bool isAdmin { get; set; }
        public string UserName { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class Register
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Password { get; set; }
        public string Company { get; set; }
        public string PushId { get; set; }

    }

    public class UserImage
    {
        public string image { get; set; }
        public int id { get; set; }

    }
    #endregion
}
